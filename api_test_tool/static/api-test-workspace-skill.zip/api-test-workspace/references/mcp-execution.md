# 执行约定已更新

当前执行约定见 [API 测试台接入](workspace-execution.md)，包含缺失鉴权负向测试的标记、数据清理及覆盖清单保存方式。完整要求见 [SKILL.md](../SKILL.md)。
